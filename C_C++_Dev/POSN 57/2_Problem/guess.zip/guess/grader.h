int bigger(int K);
