int play(int N);
