#include "tourist.h"
int GreaterHappiness(int N, int K, int *H)
    return 0;
}
