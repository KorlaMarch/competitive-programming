#ifndef TOURIST
#define TOURIST
int GreaterHappiness(int N,int K, int *H);
#endif // TOURIST

